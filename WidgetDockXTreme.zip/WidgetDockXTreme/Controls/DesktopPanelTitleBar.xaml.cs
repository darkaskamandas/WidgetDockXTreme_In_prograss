﻿using System.Windows.Controls;

namespace DesktopPanelTool.Controls
{
    /// <summary>
    /// Logique d'interaction pour DesktopPanelTitleBar.xaml
    /// </summary>
    public partial class DesktopPanelTitleBar : UserControl
    {
        public DesktopPanelTitleBar()
        {
            InitializeComponent();
        }
    }
}
