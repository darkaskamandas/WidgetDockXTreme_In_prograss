﻿using System.Windows.Controls;

namespace DesktopPanelTool.Controls
{
    public partial class DesktopPanelToolButtonsBar : UserControl
    {
        public DesktopPanelToolButtonsBar()
        {
            InitializeComponent();
        }
    }
}
