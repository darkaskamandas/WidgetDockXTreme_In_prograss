﻿namespace DesktopPanelTool.Lib
{
    public class DefaultInteractionEventHandler
    {
        public void ClickEventHandler()
        {            
        }
    }
}
