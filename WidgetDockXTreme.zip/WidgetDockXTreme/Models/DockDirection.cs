﻿namespace DesktopPanelTool.Lib.Models
{
    public enum DockDirection
    {
        Horizontal,
        Vertical,
        None
    }
}
