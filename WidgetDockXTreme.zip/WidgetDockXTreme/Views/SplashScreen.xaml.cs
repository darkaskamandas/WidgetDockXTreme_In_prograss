﻿using System.Windows;

namespace DesktopPanelTool.Views
{
    /// <summary>
    /// Logique d'interaction pour SplashScreen.xaml
    /// </summary>
    internal partial class SplashScreen : Window
    {
        public SplashScreen()
        {
            InitializeComponent();
        }
    }
}
