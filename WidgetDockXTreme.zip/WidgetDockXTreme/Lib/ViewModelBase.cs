﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesktopPanelTool.Lib
{
    [Serializable]
    public class ViewModelBase
        : ModelBase
    {
    }
}
