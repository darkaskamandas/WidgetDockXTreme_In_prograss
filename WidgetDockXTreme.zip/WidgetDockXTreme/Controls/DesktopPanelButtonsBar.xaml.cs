﻿using System.Windows.Controls;

namespace DesktopPanelTool.Controls
{
    /// <summary>
    /// Logique d'interaction pour WidgetButtonsBar.xaml
    /// </summary>
    public partial class DesktopPanelButtonsBar : UserControl
    {
        public DesktopPanelButtonsBar()
        {
            InitializeComponent();
        }
    }
}
