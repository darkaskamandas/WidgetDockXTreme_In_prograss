﻿using System;
using System.Windows;

namespace DesktopPanelTool.Views
{
    public partial class DesktopPanelToolWindow : Window
    {
        public DesktopPanelToolWindow()
        {
            InitializeComponent();
        }
    }
}
