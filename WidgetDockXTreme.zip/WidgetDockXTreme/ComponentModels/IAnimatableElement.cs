﻿namespace DesktopPanelTool.ComponentModels
{
    internal interface IAnimatableElement
    {
        public double WidthBackup { get; set; }
        public double HeightBackup { get; set; }
    }
}
