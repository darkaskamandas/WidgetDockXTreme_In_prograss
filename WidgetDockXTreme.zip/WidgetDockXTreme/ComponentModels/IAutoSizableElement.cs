﻿using DesktopPanelTool.ViewModels;

namespace DesktopPanelTool.ComponentModels
{
    public interface IAutoSizableElement
    {
        public AutoSizableElementViewModel AutoSizableElementViewModel { get; set; }
    }
}
