﻿using System.Windows.Controls;

namespace DesktopPanelTool.Controls
{
    public partial class DesktopPanelToolTitleBar : UserControl
    {
        public DesktopPanelToolTitleBar()
        {
            InitializeComponent();
        }
    }
}
