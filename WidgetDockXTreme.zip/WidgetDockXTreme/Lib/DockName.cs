﻿namespace DesktopPanelTool.Lib
{
    public enum DockName
    {
        Left,
        Top,
        Right,
        Bottom,
        None
    }
}
